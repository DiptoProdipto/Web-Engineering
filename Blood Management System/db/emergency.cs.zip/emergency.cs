using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Project
{
    #region Emergency
    public class Emergency
    {
        #region Member Variables
        protected int _postID;
        protected string _username;
        protected string _description;
        #endregion
        #region Constructors
        public Emergency() { }
        public Emergency(string username, string description)
        {
            this._username=username;
            this._description=description;
        }
        #endregion
        #region Public Properties
        public virtual int PostID
        {
            get {return _postID;}
            set {_postID=value;}
        }
        public virtual string Username
        {
            get {return _username;}
            set {_username=value;}
        }
        public virtual string Description
        {
            get {return _description;}
            set {_description=value;}
        }
        #endregion
    }
    #endregion
}